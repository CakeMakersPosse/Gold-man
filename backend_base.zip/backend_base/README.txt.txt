Database created with 3 tables using SQLite
-products
-users
-purchase_orders

Migrations done
Tables have all columns and foreign key associations

Nodemon installed
Database Syncs and loads on localhost:3000
Nothing should be on that page except "Welcome to Express"